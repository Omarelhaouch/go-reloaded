package reloaded

import "strings"

func ConvertUpLowCap(s []string) []string {
	for i, tag := range s {
		if tag == "(low)" {
			if i > 0 && i < len(s) {
				// Convert the previous element to lowercase
				s[i-1] = strings.ToLower(s[i-1])
				// Remove the tag element from the current element
				s = RmIndex(s, i)
			} else if i == 0 {
				// Remove the tag element from the current element
				s[0] = strings.ReplaceAll(s[0], "(low)", "")
			}
		} else if tag == "(up)" && i < len(s) {
			if i > 0 && i < len(s) {
				s[i-1] = strings.ToUpper(s[i-1])
				s = RmIndex(s, i)
			} else if i == 0 {
				s[0] = strings.ReplaceAll(s[0], "(up)", "")
			}

		} else if tag == "(cap)" && i < len(s) {
			if i > 0 && i < len(s) {
				s[i-1] = strings.Title(s[i-1])
				s = RmIndex(s, i)
			} else if i == 0 {
				s[0] = strings.ReplaceAll(s[0], "(cap)", "")
			}
		}
	}
	return s
}
