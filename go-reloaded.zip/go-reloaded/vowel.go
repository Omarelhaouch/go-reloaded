package reloaded

import "strings"

func Vowel(s []string) []string {
	for i, val := range s {
		// Check if the word is "a" or "A", and if it's not the first or last word in the slice.
		if (val == "a" || val == "A") && (i > 0 && i < len(s)-1) {
			// Define a list of vowels and consonant-like letters that could influence the article.
			vowels := []string{"a", "e", "i", "o", "u", "h", "A", "E", "I", "O", "U", "H"}
			// Check each character in the list of vowels.
			for _, char := range vowels {
				// If the next word starts with a vowel or consonant-like letter,
				if strings.HasPrefix(s[i+1], char) {
					// Ensure that we are not accessing elements beyond the slice length.
					if i+1 < len(s)-1 {
						// If it's not the first word in the slice, add "n" to the word.
						if i > 0 {
							s[i] = val + "n"
						}
					}
				}
			}
		}
	}
	return s
}
