package reloaded

import "strings"

func Punctuations(s []string) []string {
	speChars := []string{".", ",", "!", "?", ":", ";"}
	for idx := 1; idx < len(s); idx++ {
		for j := 0; j < len(speChars); j++ {
			// Check if the current element is the same as the special character
			if s[idx] == speChars[j] {
				// Concatenate the special character with the previous element
				s[idx-1] = s[idx-1] + speChars[j]
				// Remove the current element from the slice
				s = RmIndex(s, idx)
				// Decrement idx to adjust for the removed element
				idx--
			} else if strings.HasPrefix(s[idx], speChars[j]) {
				// Concatenate the special character with the previous element
				s[idx-1] = s[idx-1] + speChars[j]
				// Remove the first character (special character) from the current element
				s[idx] = s[idx][1:]
			}
		}
	}
	return s
}
