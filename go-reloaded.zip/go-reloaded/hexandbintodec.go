package reloaded

import (
	"fmt"
	"strconv"
	"strings"
)

func HexAndBinToDec(s []string) []string {
	for i, tag := range s {
		if tag == "(hex)" {
			if i > 0 && i < len(s) {
				// Convert the previous element from hexadecimal to decimal
				dec, err := strconv.ParseInt(s[i-1], 16, 64)
				s[i-1] = strconv.Itoa(int(dec))
				// Remove the tag element from the slice
				s = RmIndex(s, i)
				// Print an error message if conversion fails
				if err != nil {
					fmt.Printf("ERROR")
				}
			} else if i == 0 {
				s[0] = strings.ReplaceAll(s[0], "(hex)", "")
			}
		} else if tag == "(bin)" {
			if i > 0 && i < len(s) {
				dec, err := strconv.ParseInt(s[i-1], 2, 64)
				s[i-1] = strconv.Itoa(int(dec))
				s = RmIndex(s, i)
				if err != nil {
					fmt.Printf("ERROR")
				}
			} else if i == 0 {
				s[0] = strings.ReplaceAll(s[0], "(bin)", "")
			}
		}
	}
	return s
}
